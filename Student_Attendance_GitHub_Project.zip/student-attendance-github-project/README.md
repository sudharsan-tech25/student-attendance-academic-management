# Cloud-Based Student Attendance and Academic Record Management System

A beginner-friendly DBMS mini project built with **Python Flask, SQLite, HTML and CSS**.

## Features
- Dashboard with student, course, attendance and marks counts
- Add and delete student records
- Add and delete courses
- Record daily attendance (Present/Absent)
- Enter assessment marks and calculate percentages
- Attendance percentage and academic performance reports
- Relational tables, primary keys, foreign keys, unique constraints and validation
- Responsive interface for mobile and desktop

## Database tables
- `students`
- `courses`
- `attendance`
- `marks`

The SQLite database is created automatically when the application starts. A few demo students and courses are inserted on the first run.

## Run locally

1. Install Python 3.10 or later.
2. Open a terminal in this project folder.
3. Create and activate a virtual environment (optional but recommended).

   **Windows**
   ```bash
   python -m venv .venv
   .venv\Scripts\activate
   ```

   **macOS/Linux**
   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   ```

4. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
5. Start the application:
   ```bash
   python app.py
   ```
6. Open `http://127.0.0.1:5000` in your browser.

## Upload to GitHub

1. Sign in to GitHub and create a new repository, for example `student-attendance-academic-management`.
2. Keep the repository public if your instructor needs to view it.
3. Upload the extracted project files and folders (do not upload `.venv` or the generated database).
4. Add this README as the repository description/documentation.
5. Commit the files.

> GitHub stores the source code; it does not automatically run a Flask application. For a live website, deploy the app to a Python hosting service and configure the database appropriately. This project is a learning/demo prototype and does not include login or production security.

## Project structure

```text
student-attendance-github-project/
├── app.py
├── requirements.txt
├── README.md
├── .gitignore
├── templates/
│   ├── base.html
│   ├── index.html
│   ├── students.html
│   ├── courses.html
│   ├── attendance.html
│   ├── marks.html
│   └── reports.html
└── static/
    └── style.css
```

## Main DBMS concepts demonstrated
- Relational database design
- Primary and foreign keys
- UNIQUE and CHECK constraints
- CRUD operations
- SQL JOIN, GROUP BY, COUNT, SUM and CASE expressions
- Referential integrity
- Attendance and marks calculations

## Author
Add your name, register number, department and college details here.
